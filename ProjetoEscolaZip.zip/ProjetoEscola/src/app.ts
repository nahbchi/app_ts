import { Endereco } from "./endereco";
import { Turma } from "./turma";
import { Escola } from "./escola";
import { Estudante } from "./estudante";

const endEstud = new Endereco("A","70",20,"MT","VG","Quadra","Kc","8324");
const endEsc = new Endereco("A","79",30,"MT","VG","Quadra","Kc","8322");

const escola = new Escola("SesiLandia",endEsc);
const turma = new Turma("Terceirinho", 3)

const aluno = new Estudante("Caioto", 17, "000", 15, escola, turma, endEstud);

aluno.exibirInfo();