import { Pessoa } from "./pessoa";
import { Escola } from "./escola";
import { Turma } from "./turma";
import { Endereco } from "./endereco";

export class Estudante extends Pessoa {
    matricula: number;
    escola: Escola;
    turma: Turma;
    endereco: Endereco;

    constructor(nome: string, idade: number, cpf: string,
        matricula: number, escola: Escola, turma: Turma, endereco: Endereco) {
        super(nome, idade, cpf);
        this.matricula = matricula;
        this.escola = escola;
        this.turma = turma;
        this.endereco = endereco;
    }
    exibirInfo(): void {
        console.log(`
            Nome: ${this.nome}, Idade: ${this.idade}, CPF: ${this.cpf},
            Matricula: ${this.matricula} 
            `);
        console.log(`Escola: ${this.escola.exibirInfo()}`);
        console.log(`Turma: ${this.turma.exibirInfo()}`);
        console.log(`Endereço: ${this.endereco.exibirInfo()}`);
    }
}
