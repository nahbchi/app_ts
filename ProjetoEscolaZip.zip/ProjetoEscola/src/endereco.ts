export class Endereco{
    logradouro: string;
    complemento: string;
    numero: number;
    bairro: string;
    cidade: string;
    estado: string;
    uf: string;
    cep: string;
    
    constructor(logradouro:string,complemento:string,numero:number,bairro:string,cidade:string,estado:string,uf:string,cep:string){
        this.logradouro = logradouro;
        this.complemento = complemento;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.uf = uf;
        this.cep = cep;
    }
    exibirInfo():void{
        console.log(`
        Estado = ${this.estado},
        UF = ${this.uf},
        Cidade = ${this.cidade},
        Logradouro = ${this.logradouro},
        Bairro = ${this.bairro},
        Complemento = ${this.complemento},
        Número = ${this.numero},
        cep = ${this.cep}
           `);
    }
    

}