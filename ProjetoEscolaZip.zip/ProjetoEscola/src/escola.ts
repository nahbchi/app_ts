import { Endereco } from "./endereco";

export class Escola{
nome:string;
endereco: Endereco;

constructor(nome:string, end: Endereco){
 this.nome = nome;
 this.endereco = end;
}

exibirInfo():void{
    console.log(`
    Nome = ${this.nome}
    `);
    console.log("Endereço da instituição: ");
    this.endereco.exibirInfo();
}
}