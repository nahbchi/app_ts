export class Turma {

    nome: string;
    ano: number;

    constructor(nome: string, ano: number) {

        this.nome = nome;
        this.ano = ano;
    }

    exibirInfo(): void {
        console.log(`
     Nome turma: ${this.nome},
     Ano Turma: ${this.ano},
     `);
    }
    
}